const EventEmitter = require('events');

class EventBroker extends EventEmitter {
    constructor() {
        super();
        // Increase listeners cap for high-throughput event processing simulated models
        this.setMaxListeners(50);
    }

    publish(eventName, payload) {
        console.log(`[EVENT BROKER] Broadcast Event: "${eventName}" at ${new Date().toISOString()}`);
        // Defer execution using setImmediate to achieve asynchronous event loops
        setImmediate(() => {
            this.emit(eventName, payload);
        });
    }

    subscribe(eventName, listenerCallback) {
        this.on(eventName, listenerCallback);
        console.log(`[EVENT BROKER] Service Subscribed to topic: "${eventName}"`);
    }
}

// Singleton pattern instantiation to share across simulated services
const brokerInstance = new EventBroker();
module.exports = brokerInstance;