const eventBroker = require('../broker/EventBroker');

class NotificationService {
    constructor() {
        this.log = [];
    }

    initialize() {
        console.log('[Notification Service] Channel online. Monitoring all system domains.');

        // React to all event variations inside the system lifecycle
        eventBroker.subscribe('ApplicationSubmitted', (payload) => {
            this.sendEmail(payload.email, 'Application Received', `Hello ${payload.name}, your application (ID: ${payload.id}) has been submitted.`);
        });

        eventBroker.subscribe('ResumeScreened', (payload) => {
            if (!payload.passed) {
                this.sendEmail(payload.candidateEmail, 'Status Update', `Hello ${payload.candidateName}, thank you for applying. We will not be moving forward with your application at this time.`);
            }
        });

        eventBroker.subscribe('InterviewScheduled', (payload) => {
            this.sendEmail(payload.candidateEmail, 'Interview Invitation', `Great news ${payload.candidateName}! Your technical assessment interview is set for ${payload.dateScheduled.toLocaleDateString()}.`);
        });
    }

    sendEmail(to, subject, body) {
        const notificationEntry = {
            notificationId: 'NTF_' + Math.floor(Math.random() * 99999),
            recipient: to,
            subject: subject,
            timestamp: new Date()
        };
        this.log.push(notificationEntry);
        
        console.log('\n------------------------------------------------------------');
        console.log(`[NOTIFICATION OUTBOUND EMAIL]`);
        console.log(`TO:      ${to}`);
        console.log(`SUBJECT: ${subject}`);
        console.log(`BODY:    ${body}`);
        console.log('------------------------------------------------------------\n');
    }
}

module.exports = new NotificationService();