const eventBroker = require('../broker/EventBroker');

class InterviewService {
    constructor() {
        this.db = [];
    }

    initialize() {
        console.log('[Interview Service] Initialized and watching screening outcomes.');

        // Subscribe to Screening Outbound Events
        eventBroker.subscribe('ResumeScreened', (screeningResult) => {
            if (screeningResult.passed) {
                this.scheduleInterview(screeningResult);
            } else {
                console.log(`[Interview Service] Application ${screeningResult.applicationId} skipped due to low screening score.`);
            }
        });
    }

    scheduleInterview(screeningResult) {
        const interviewSlot = {
            interviewId: 'INT_' + Math.floor(Math.random() * 90000),
            applicationId: screeningResult.applicationId,
            candidateName: screeningResult.candidateName,
            candidateEmail: screeningResult.candidateEmail,
            dateScheduled: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Plus 7 days out
            status: 'SCHEDULED'
        };

        this.db.push(interviewSlot);
        console.log(`[Interview Service] Scheduled interview for Application ID: ${interviewSlot.applicationId}`);

        // Broadcast scheduling event
        eventBroker.publish('InterviewScheduled', interviewSlot);
    }
}

module.exports = new InterviewService();