const eventBroker = require('../broker/EventBroker');

class ApplicationService {
    constructor() {
        this.db = []; // Independent encapsulated service datastore
    }

    initialize() {
        console.log('[Application Service] Initialized successfully.');
    }

    createApplication(candidateName, candidateEmail, resumeKeywords) {
        const application = {
            id: 'APP_' + Math.floor(Math.random() * 100000),
            name: candidateName,
            email: candidateEmail,
            keywords: resumeKeywords || [],
            status: 'SUBMITTED',
            createdAt: new Date()
        };

        this.db.push(application);
        console.log(`[Application Service] Data saved. Assigned ID: ${application.id}`);

        // Broadcast emission to the event broker
        eventBroker.publish('ApplicationSubmitted', application);
        
        return application;
    }

    getApplications() {
        return this.db;
    }
}

module.exports = new ApplicationService();