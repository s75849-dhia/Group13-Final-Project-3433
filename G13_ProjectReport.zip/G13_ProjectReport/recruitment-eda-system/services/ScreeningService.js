const eventBroker = require('../broker/EventBroker');

class ScreeningService {
    constructor() {
        this.db = [];
    }

    initialize() {
        console.log('[Screening Service] Initialized and watching event lines.');
        
        // Listen to Application Ingestion Topic asynchronously
        eventBroker.subscribe('ApplicationSubmitted', (application) => {
            this.processScreening(application);
        });
    }

    processScreening(application) {
        console.log(`[Screening Service] Evaluating application constraints for ID: ${application.id}`);
        
        // Automation Evaluation Logic (Requires keyword verification match)
        const hasRequiredSkills = application.keywords.some(skill => 
            ['javascript', 'node', 'architecture', 'express'].includes(skill.toLowerCase())
        );

        const screeningResult = {
            screeningId: 'SCR_' + Math.floor(Math.random() * 90000),
            applicationId: application.id,
            candidateName: application.name,
            candidateEmail: application.email,
            passed: hasRequiredSkills,
            score: hasRequiredSkills ? 85 : 40,
            reviewedAt: new Date()
        };

        this.db.push(screeningResult);
        console.log(`[Screening Service] Processed ID: ${application.id}. Status Passed: ${screeningResult.passed}`);

        // Dispatch screening outcome event
        eventBroker.publish('ResumeScreened', screeningResult);
    }
}

module.exports = new ScreeningService();