const express = require('express');
const app = express();
const PORT = 3000;

// Import architectural service layers
const applicationService = require('./services/ApplicationService');
const screeningService = require('./services/ScreeningService');
const interviewService = require('./services/InterviewService');
const notificationService = require('./services/NotificationService');

// Middleware to parse JSON payloads and URL-encoded form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Boot and mount asynchronous infrastructure services
applicationService.initialize();
screeningService.initialize();
interviewService.initialize();
notificationService.initialize();

// NEW: Serve a Web Browser Form Interface directly from the server root
app.get('/', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>EDA Job Recruitment Portal</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; margin: 0; padding: 40px; display: flex; justify-content: center; }
            .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 100%; max-width: 500px; }
            h2 { color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
            .form-group { margin-bottom: 15px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #34495e; }
            input[type="text"], input[type="email"] { width: 100%; padding: 10px; border: 1px solid #bdc3c7; border-radius: 4px; box-sizing: border-box; font-size: 14px; }
            .checkbox-group { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 5px; }
            .checkbox-item { display: flex; align-items: center; gap: 5px; }
            button { background-color: #3498db; color: white; border: none; padding: 12px; width: 100%; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer; margin-top: 15px; transition: background 0.2s; }
            button:hover { background-color: #2980b9; }
            #response-log { margin-top: 20px; padding: 15px; border-radius: 4px; display: none; font-family: monospace; font-size: 13px; }
            .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Job Application Portal</h2>
            <form id="applicationForm">
                <div class="form-group">
                    <label for="name">Full Name:</label>
                    <input type="text" id="name" required placeholder="e.g. Jane Doe">
                </div>
                <div class="form-group">
                    <label for="email">Email Address:</label>
                    <input type="email" id="email" required placeholder="e.g. jane@example.com">
                </div>
                <div class="form-group">
                    <label>Select Your Skills (Resume Keywords):</label>
                    <div class="checkbox-group">
                        <div class="checkbox-item"><input type="checkbox" name="skills" value="Node"> Node.js</div>
                        <div class="checkbox-item"><input type="checkbox" name="skills" value="Architecture"> Architecture</div>
                        <div class="checkbox-item"><input type="checkbox" name="skills" value="Express"> Express</div>
                        <div class="checkbox-item"><input type="checkbox" name="skills" value="JavaScript"> JavaScript</div>
                        <div class="checkbox-item"><input type="checkbox" name="skills" value="Sales"> Sales/Marketing</div>
                        <div class="checkbox-item"><input type="checkbox" name="skills" value="Excel"> Microsoft Excel</div>
                    </div>
                </div>
                <button type="submit">Submit Application</button>
            </form>
            <div id="response-log"></div>
        </div>

 <script>
    document.getElementById('applicationForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const checkboxes = document.querySelectorAll('input[name="skills"]:checked');
        const keywords = Array.from(checkboxes).map(cb => cb.value);

        const responseLog = document.getElementById('response-log');

        try {
            const res = await fetch('/api/apply', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, keywords })
            });

            const data = await res.json();

            responseLog.style.display = 'block';
            responseLog.className = 'success';
            responseLog.innerHTML = '<strong>Status Code: ' + res.status + ' (Accepted)</strong><br><br>' + JSON.stringify(data, null, 2).replace(/\n/g, '<br>');
        } catch (err) {
            responseLog.style.display = 'block';
            responseLog.style.backgroundColor = '#f8d7da';
            responseLog.style.color = '#721c24';
            responseLog.innerText = 'Error connecting to the EDA Gateway.';
        }
    });
    </script>
    </body>
    </html>
    `);
});

// Core REST Route for Application Submission (Shared by Postman and Web Browser Form)
app.post('/api/apply', (req, res) => {
    const { name, email, keywords } = req.body;
    
    if (!name || !email) {
        return res.status(400).json({ error: 'Missing client name or contact email address.' });
    }

    // Process ingestion asynchronously via event streams
    const applicationRecord = applicationService.createApplication(name, email, keywords);
    
    // Return Immediate status acknowledgement (Decoupled execution loop)
    return res.status(202).json({
        message: 'Application ingested and queued for background screening processing.',
        applicationId: applicationRecord.id,
        status: applicationRecord.status
    });
});

app.listen(PORT, () => {
    console.log(`================================================================`);
    console.log(`EDA RECRUITMENT CLUSTER SERVER RUNNING ON http://localhost:${PORT}`);
    console.log(`================================================================`);
});